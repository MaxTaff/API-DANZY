// app.js - Main Application Script

class DausToolsApp {
    constructor() {
        this.init();
        this.setupEventListeners();
        this.setupAnimations();
        this.checkDarkModePreference();
        this.setupThemeToggle();
        this.loadUserData();
    }

    init() {
        // Initialize core application state
        this.state = {
            isLoggedIn: false,
            currentUser: null,
            theme: localStorage.getItem('theme') || 'light',
            notifications: [],
            currentPage: window.location.pathname
        };
        
        // Setup socket connection if needed
        this.setupSocketConnection();
    }

    setupEventListeners() {
        // Mobile menu toggle
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('nav-menu');
        
        if (hamburger && navMenu) {
            hamburger.addEventListener('click', () => {
                navMenu.classList.toggle('active');
                hamburger.classList.toggle('active');
            });
        }

        // Form submissions
        document.addEventListener('submit', (e) => {
            if (e.target.closest('.login-form')) {
                e.preventDefault();
                this.handleLogin(e.target);
            }
            if (e.target.closest('.register-form')) {
                e.preventDefault();
                this.handleRegister(e.target);
            }
        });
        // Click outside to close mobile menu
        document.addEventListener('click', (e) => {
            if (navMenu && !navMenu.contains(e.target) && !hamburger.contains(e.target)) {
                navMenu.classList.remove('active');
                hamburger.classList.remove('active');
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Theme toggle button
        const themeToggle = document.querySelector('.theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Notification system
        this.setupNotificationSystem();
    }

    setupAnimations() {
        // Fade-in animation for elements when they come into view
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe elements with fade-in class
        document.querySelectorAll('.fade-in-up, .feature-card, .stat-card, .package-card').forEach(el => {            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });

        // Animate stats counters
        this.animateStatCounters();
    }

    animateStatCounters() {
        const statElements = document.querySelectorAll('[id$="-count"]');
        statElements.forEach(el => {
            const finalValue = parseInt(el.textContent);
            if (!isNaN(finalValue)) {
                this.animateCounter(el, 0, finalValue);
            }
        });
    }

    animateCounter(element, start, end) {
        let current = start;
        const increment = end > start ? 1 : -1;
        const duration = 2000;
        const stepTime = Math.abs(Math.floor(duration / (end - start)));
        
        const timer = setInterval(() => {
            current += increment;
            element.textContent = current;
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                clearInterval(timer);
            }
        }, stepTime);
    }

    checkDarkModePreference() {
        // Check for saved theme preference or system preference
        const savedTheme = localStorage.getItem('theme');
        const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        
        if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
            document.body.classList.add('dark-mode');
        }
    }

    setupThemeToggle() {
        // Create theme toggle button if it doesn't exist
        if (!document.querySelector('.theme-toggle')) {
            const toggleBtn = document.createElement('button');
            toggleBtn.className = 'theme-toggle btn btn-outline';            toggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            toggleBtn.title = 'Toggle Dark Mode';
            
            toggleBtn.addEventListener('click', () => this.toggleTheme());
            
            // Add to navbar
            const navContainer = document.querySelector('.nav-container');
            if (navContainer) {
                navContainer.appendChild(toggleBtn);
            }
        }
    }

    toggleTheme() {
        document.body.classList.toggle('dark-mode');
        const isDarkMode = document.body.classList.contains('dark-mode');
        
        // Update localStorage
        localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        
        // Update icon
        const icon = document.querySelector('.theme-toggle i');
        if (icon) {
            icon.className = isDarkMode ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    setupSocketConnection() {
        // Initialize Socket.IO if available
        if (typeof io !== 'undefined') {
            this.socket = io();
            this.socket.on('connect', () => {
                console.log('Connected to server');
            });
            
            this.socket.on('notification', (data) => {
                this.showNotification(data.message, data.type);
            });
        }
    }

    setupNotificationSystem() {
        // Create notification container
        if (!document.getElementById('notification-container')) {
            const container = document.createElement('div');
            container.id = 'notification-container';
            container.className = 'notifications';
            document.body.appendChild(container);
        }
    }
    showNotification(message, type = 'info') {
        const container = document.getElementById('notification-container');
        const notification = document.createElement('div');
        notification.className = `notification notification-${type} fade-in`;
        notification.innerHTML = `
            <span>${message}</span>
            <button class="close-btn">&times;</button>
        `;
        
        container.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            this.removeNotification(notification);
        }, 5000);
        
        // Close button event
        notification.querySelector('.close-btn').addEventListener('click', () => {
            this.removeNotification(notification);
        });
    }

    removeNotification(notification) {
        notification.classList.add('fade-out');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }

    async handleLogin(form) {
        const formData = new FormData(form);
        const credentials = Object.fromEntries(formData);
        
        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(credentials)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showNotification('Login successful!', 'success');
                // Update UI state
                this.updateAuthState(result.user);
                // Redirect to dashboard                setTimeout(() => {
                    window.location.href = '/dashboard';
                }, 1000);
            } else {
                this.showNotification(result.message || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            this.showNotification('Network error occurred', 'error');
        }
    }

    async handleRegister(form) {
        const formData = new FormData(form);
        const userData = Object.fromEntries(formData);
        
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(userData)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showNotification('Registration successful! Please verify your email.', 'success');
                // Redirect to login
                setTimeout(() => {
                    window.location.href = '/login';
                }, 2000);
            } else {
                this.showNotification(result.message || 'Registration failed', 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            this.showNotification('Network error occurred', 'error');
        }
    }

    updateAuthState(user) {
        this.state.isLoggedIn = true;
        this.state.currentUser = user;
        
        // Update UI elements
        const loginLink = document.querySelector('a[href="/login"]');
        const logoutLink = document.querySelector('a[href="/logout"]');
        const profileLink = document.querySelector('a[href="/profile"]');        
        if (loginLink) loginLink.remove();
        if (logoutLink) logoutLink.style.display = 'block';
        if (profileLink) profileLink.innerHTML = `Hi, ${user.name}`;
    }

    async loadUserData() {
        // Load user-specific data if authenticated
        if (this.state.currentUser) {
            try {
                const response = await fetch(`/api/user/${this.state.currentUser.id}/data`);
                if (response.ok) {
                    const userData = await response.json();
                    this.updateUserData(userData);
                }
            } catch (error) {
                console.error('Error loading user data:', error);
            }
        }
    }

    updateUserData(data) {
        // Update dashboard with user data
        const creditElement = document.getElementById('credit-count');
        if (creditElement) {
            creditElement.textContent = data.credits || 0;
        }
        
        // Update other user-specific elements
        const apiCallsElement = document.getElementById('api-calls');
        if (apiCallsElement) {
            apiCallsElement.textContent = data.apiCalls || 0;
        }
    }

    // Utility methods
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    throttle(func, limit) {
        let inThrottle;        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }

    // QR Code Generator Helper
    generateQRCode(text) {
        // This would typically use a QR library like qrcode.js
        // For now, we'll return a placeholder
        console.log('Generating QR code for:', text);
        return `data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="white"/><text x="50" y="55" font-family="Arial" font-size="8" fill="black" text-anchor="middle">${encodeURIComponent(text)}</text></svg>`;
    }

    // Format numbers with commas
    formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    // Get current timestamp
    getCurrentTimestamp() {
        return new Date().toISOString();
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new DausToolsApp();
});

// Export for module usage (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DausToolsApp;
}

// Additional utility functions
function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {        window.app.showNotification('Copied to clipboard!', 'success');
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
}

// Performance monitoring
window.addEventListener('load', () => {
    const loadTime = performance.now();
    console.log(`Page loaded in ${loadTime} milliseconds`);
});

// Error handling
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    if (window.app) {
        window.app.showNotification('An error occurred. Please try again.', 'error');
    }
});