const express = require('express');
const router = express.Router();

// Halaman Utama
router.get('/', (req, res) => {
    res.render('index', {
        title: 'Daus Tools - Home',
        user: req.session.user || null,
        isLoggedIn: !!req.session.user
    });
});

// Dashboard
router.get('/dashboard', (req, res) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    res.render('dashboard', {
        title: 'Dashboard - Daus Tools',
        user: req.session.user
    });
});

// Dokumentasi API
router.get('/docs', (req, res) => {
    res.render('docs', {
        title: 'API Documentation'
    });
});

// Tools Page
router.get('/tools', (req, res) => {
    res.render('tools', {
        title: 'Tools - Daus Tools'
    });
});

// Random Page
router.get('/random', (req, res) => {
    res.render('random', {
        title: 'Random Generators - Daus Tools'
    });
});

// Downloader Page
router.get('/downloader', (req, res) => {
    res.render('downloader', {
        title: 'Downloader - Daus Tools'
    });
});

// About Page (Tentang)
router.get('/about', (req, res) => {
    const sekolahData = {
        nama: 'SMP Negeri 6 Tanjung Selor',
        alias: 'sekolah penggerak',
        status: 'Negeri',
        kurikulum: 'SMP Merdeka',
        alamat: 'Jl. Poros Tanjung Selor - Bunyu, Tanjung Selor',
        npsn: '30402572',
        operator: 'Slamet Gunawan',
        jumlahSiswa: 288,
        jumlahSiswaLaki: 151,
        jumlahSiswaPerempuan: 137,
        jumlahGuru: 15,
        jumlahRuangKelas: 9,
        jumlahLaboratorium: 2,
        luasArea: '19,800 m²',
        listrik: 'Tidak ada',
        internet: 'Tidak ada',
        akreditasi: 'B',
        rasioSiswaGuru: 20
    };
    
    res.render('about', {
        title: 'Tentang Sekolah - Daus Tools',
        sekolah: sekolahData
    });
});

module.exports = router;