const express = require('express');
const router = express.Router();

// Endpoint dasar
router.get('/', (req, res) => {
    res.json({
        message: 'Welcome to Daus Tools API',
        version: '1.0.0',
        endpoints: [
            '/api/ai',
            '/api/downloader',
            '/api/search',
            '/api/tools',
            '/api/games',
            '/api/image',
            '/api/info',
            '/api/random',
            '/api/text'
        ]
    });
});

// Grouping routes
router.use('/ai', require('../api/ai/index'));
router.use('/downloader', require('../api/downloader/index'));
router.use('/search', require('../api/search/index'));
router.use('/tools', require('../api/tools/index'));
router.use('/games', require('../api/games/index'));
router.use('/image', require('../api/image/index'));
router.use('/info', require('../api/info/index'));
router.use('/random', require('../api/random/index'));
router.use('/text', require('../api/text/index'));

module.exports = router;