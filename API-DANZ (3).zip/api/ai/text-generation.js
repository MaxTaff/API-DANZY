// api/ai/text-generation.js
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-pro' });

class TextGenerator {
    static async generateText(req, res) {
        try {
            const { prompt, maxLength = 1000, temperature = 0.7 } = req.body;
            
            if (!prompt) {
                return res.status(400).json({
                    error: 'Prompt is required'
                });
            }

            const result = await model.generateContent(prompt);
            const response = await result.response;
            const text = response.text();

            res.json({
                success: true,
                generated_text: text,
                model_used: 'gemini-pro',
                tokens_used: text.split(' ').length
            });

        } catch (error) {
            console.error('Text generation error:', error);
            res.status(500).json({
                error: 'Failed to generate text',
                details: error.message
            });
        }
    }

    static async summarize(req, res) {
        try {
            const { text, max_length = 100 } = req.body;
            
            if (!text) {
                return res.status(400).json({
                    error: 'Text is required for summarization'
                });
            }

            const prompt = `Please summarize the following text in ${max_length} characters or less:\n\n${text}`;
            const result = await model.generateContent(prompt);            const response = await result.response;
            const summary = response.text();

            res.json({
                success: true,
                original_text_length: text.length,
                summary: summary,
                compression_ratio: (summary.length / text.length * 100).toFixed(2) + '%'
            });

        } catch (error) {
            res.status(500).json({
                error: 'Summarization failed',
                details: error.message
            });
        }
    }

    static async translate(req, res) {
        try {
            const { text, target_lang = 'en', source_lang = 'auto' } = req.body;
            
            if (!text || !target_lang) {
                return res.status(400).json({
                    error: 'Text and target language are required'
                });
            }

            const prompt = `Translate the following text to ${target_lang}: ${text}`;
            const result = await model.generateContent(prompt);
            const response = await result.response;
            const translated = response.text();

            res.json({
                success: true,
                original_text: text,
                translated_text: translated,
                source_language: source_lang,
                target_language: target_lang
            });

        } catch (error) {
            res.status(500).json({
                error: 'Translation failed',
                details: error.message
            });
        }
    }
}
module.exports = TextGenerator;