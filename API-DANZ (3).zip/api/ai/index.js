// api/ai/index.js
const express = require('express');
const router = express.Router();
const textGeneration = require('./text-generation');
const imageAnalysis = require('./image-analysis');
const chatCompletion = require('./chat-completion');
const { rateLimit } = require('./middleware/rate-limit');

// Apply rate limiting to all AI routes
router.use(rateLimit);

// Text Generation Routes
router.post('/generate-text', textGeneration.generateText);
router.post('/summarize', textGeneration.summarize);
router.post('/translate', textGeneration.translate);

// Image Analysis Routes
router.post('/image-to-text', imageAnalysis.extractText);
router.post('/analyze-image', imageAnalysis.analyzeImage);
router.post('/image-description', imageAnalysis.describeImage);

// Chat Completion Routes
router.post('/chat', chatCompletion.chatWithAI);
router.post('/conversation', chatCompletion.startConversation);

// Health check
router.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        service: 'AI Service',
        timestamp: new Date().toISOString(),
        endpoints: [
            'POST /api/ai/generate-text',
            'POST /api/ai/chat',
            'POST /api/ai/image-to-text'
        ]
    });
});

// Error handling middleware
router.use((err, req, res, next) => {
    console.error('AI API Error:', err);
    res.status(500).json({
        error: 'AI Service Error',
        message: err.message
    });
});

module.exports = router;