// api/ai/middleware/rate-limit.js
const rateLimit = require('express-rate-limit');

const aiRateLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Batasi 100 request per windowMs
    message: {
        error: 'Too many AI requests from this IP, please try again later.',
        code: 'RATE_LIMIT_EXCEEDED'
    },
    standardHeaders: true,
    legacyHeaders: false,
    skip: (req, res) => {
        // Lewati limit jika user memiliki subscription premium
        return req.user && req.user.subscription === 'premium';
    }
});

module.exports = { rateLimit: aiRateLimit };