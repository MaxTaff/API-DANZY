// api/ai/chat-completion.js
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const chatModel = genAI.getGenerativeModel({ model: 'gemini-pro' });

class ChatCompletion {
    static async chatWithAI(req, res) {
        try {
            const { message, history = [] } = req.body;
            
            if (!message) {
                return res.status(400).json({
                    error: 'Message is required'
                });
            }

            // Membuat chat session dengan history
            const chat = chatModel.startChat({
                history: history.map(msg => ({
                    role: msg.role === 'user' ? 'user' : 'model',
                    parts: [{ text: msg.content }]
                }))
            });

            const result = await chat.sendMessage(message);
            const response = await result.response;
            const reply = response.text();

            res.json({
                success: true,
                response: reply,
                conversation_id: 'gemini-' + Date.now(),
                model_used: 'gemini-pro',
                tokens_used: reply.split(' ').length
            });

        } catch (error) {
            console.error('Chat completion error:', error);
            res.status(500).json({
                error: 'Chat completion failed',
                details: error.message
            });
        }
    }

    static async startConversation(req, res) {
        try {
            const { initial_message, topic = 'general' } = req.body;
            
            if (!initial_message) {
                return res.status(400).json({
                    error: 'Initial message is required'
                });
            }

            const prompt = `You are a helpful assistant. The user wants to start a conversation about "${topic}". They said: "${initial_message}". Respond appropriately.`;
            const result = await chatModel.generateContent(prompt);
            const response = await result.response;
            const initialResponse = response.text();

            const conversationId = 'gemini-conv_' + Date.now();

            res.json({
                success: true,
                conversation_id: conversationId,
                initial_response: initialResponse,
                topic: topic,
                timestamp: new Date().toISOString()
            });

        } catch (error) {
            res.status(500).json({
                error: 'Failed to start conversation',
                details: error.message
            });
        }
    }
}

module.exports = ChatCompletion;